APK Extractor - các mức trích xuất (từ ít đến đầy đủ):
1. APK + split APK            : luôn có, không cần quyền đặc biệt.
2. + OBB + Android/data       : bật "Quyền mọi file", hoặc Shizuku (Wireless debugging), hoặc root.
3. + /data/data (dữ liệu riêng): chỉ root.
4. pc/extract_pc.sh           : qua USB/ADB, gồm cả adb backup.
Mở thư mục bằng Android Studio, Build > Build APK(s). Kết quả ở Download/APK_Extractor.
Mỗi .xapk có info.json (chữ ký SHA-256, quyền, phiên bản, ghi chú phần bị bỏ qua).
