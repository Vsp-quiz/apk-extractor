#!/bin/bash
# Dùng: ./extract_pc.sh <package>   hoặc   ./extract_pc.sh all   (mọi app người dùng cài)
# Cần: bật Gỡ lỗi USB, cài adb. Máy root thì lấy thêm /data/data.
pull_pkg() {
  P=$1; O=out/$P; mkdir -p $O/apk
  for f in $(adb shell pm path $P | sed 's/package://' | tr -d '\r'); do adb pull "$f" $O/apk/; done
  adb pull /sdcard/Android/obb/$P $O/obb 2>/dev/null
  adb pull /sdcard/Android/data/$P $O/android_data 2>/dev/null
  adb shell dumpsys package $P > $O/dumpsys.txt
  # Sao lưu dữ liệu nội bộ (chỉ app cho phép allowBackup; Android 12+ có thể bị hạn chế)
  adb backup -f $O/data.ab -apk -obb $P
  # Nếu máy root:
  adb shell "su -c 'tar -cf - -C /data/data $P'" > $O/internal_data.tar 2>/dev/null
  [ -s $O/internal_data.tar ] && [ $(stat -c%s $O/internal_data.tar 2>/dev/null || echo 0) -lt 1025 ] && rm -f $O/internal_data.tar
  echo "Xong $P"
}
if [ "$1" = "all" ]; then
  for P in $(adb shell pm list packages -3 | sed 's/package://' | tr -d '\r'); do pull_pkg $P; done
else pull_pkg $1; fi
