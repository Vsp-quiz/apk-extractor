package com.example.apkextractor

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import rikka.shizuku.Shizuku
import java.security.MessageDigest
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.File
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.concurrent.thread

class MainActivity : Activity() {

    data class AppItem(
        val label: String, val pkg: String, val version: String,
        val icon: Drawable, val files: List<File>, val size: Long, val system: Boolean
    )

    private val all = mutableListOf<AppItem>()
    private val shown = mutableListOf<AppItem>()
    private val selected = mutableSetOf<String>()
    private lateinit var adapter: BaseAdapter
    private lateinit var status: TextView
    private lateinit var search: EditText
    private lateinit var sysBox: CheckBox
    private lateinit var btn: Button
    private lateinit var extraBox: CheckBox
    private lateinit var dataBox: CheckBox

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 48, 24, 24) }
        search = EditText(this).apply { hint = "Tìm ứng dụng / package…"; setSingleLine() }
        sysBox = CheckBox(this).apply { text = "Hiện cả ứng dụng hệ thống" }
        extraBox = CheckBox(this).apply { text = "Gồm OBB + Android/data (Shizuku/root/Mọi quyền file)"; isChecked = true }
        dataBox = CheckBox(this).apply { text = "Gồm dữ liệu riêng /data/data (chỉ root)" }
        val perm = LinearLayout(this)
        perm.addView(Button(this).apply { text = "Cấp quyền Shizuku"; setOnClickListener {
            try { if (Shizuku.pingBinder()) Shizuku.requestPermission(0)
                  else Toast.makeText(context, "Hãy mở Shizuku và khởi động nó trước", Toast.LENGTH_LONG).show()
            } catch (e: Throwable) { Toast.makeText(context, "Chưa cài Shizuku", Toast.LENGTH_LONG).show() } } })
        perm.addView(Button(this).apply { text = "Quyền mọi file"; setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))) } })
        val list = ListView(this)
        status = TextView(this).apply { setPadding(0, 12, 0, 12) }
        btn = Button(this).apply { text = "Trích xuất mục đã chọn" }
        root.addView(search); root.addView(sysBox); root.addView(extraBox); root.addView(dataBox); root.addView(perm)
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(status); root.addView(btn)
        setContentView(root)

        adapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(i: Int) = shown[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, v: View?, p: ViewGroup?): View {
                val a = shown[i]
                val row = (v as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(12, 14, 12, 14)
                    addView(ImageView(context), LinearLayout.LayoutParams(96, 96))
                    addView(TextView(context).apply { textSize = 14f },
                        LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = 24 })
                }
                (row.getChildAt(0) as ImageView).setImageDrawable(a.icon)
                val splitTag = if (a.files.size > 1) " • ${a.files.size - 1} split" else ""
                (row.getChildAt(1) as TextView).text =
                    "${a.label}\n${a.pkg}\nv${a.version} • ${"%.1f".format(a.size / 1048576.0)} MB$splitTag"
                row.setBackgroundColor(if (a.pkg in selected) Color.parseColor("#BBDEFB") else Color.TRANSPARENT)
                return row
            }
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, i, _ ->
            val k = shown[i].pkg
            if (!selected.add(k)) selected.remove(k)
            adapter.notifyDataSetChanged(); updateStatus()
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = filter()
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        sysBox.setOnCheckedChangeListener { _, _ -> filter() }
        btn.setOnClickListener { extractSelected() }
        load()
    }

    private fun load() {
        status.text = "Đang quét ứng dụng…"
        thread {
            val pm = packageManager
            val items = pm.getInstalledPackages(0).mapNotNull { pi ->
                val ai = pi.applicationInfo ?: return@mapNotNull null
                val files = mutableListOf(File(ai.sourceDir))
                ai.splitSourceDirs?.forEach { files.add(File(it)) }
                AppItem(
                    ai.loadLabel(pm).toString(), pi.packageName, pi.versionName ?: "?",
                    ai.loadIcon(pm), files, files.sumOf { it.length() },
                    (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                )
            }.sortedBy { it.label.lowercase() }
            runOnUiThread { all.clear(); all.addAll(items); filter() }
        }
    }

    private fun filter() {
        val q = search.text.toString().trim().lowercase()
        shown.clear()
        shown.addAll(all.filter {
            (sysBox.isChecked || !it.system) &&
                (q.isEmpty() || it.label.lowercase().contains(q) || it.pkg.lowercase().contains(q))
        })
        adapter.notifyDataSetChanged(); updateStatus()
    }

    private fun updateStatus() { status.text = "${shown.size} ứng dụng • đã chọn ${selected.size}" }

    private fun extractSelected() {
        val todo = all.filter { it.pkg in selected }
        if (todo.isEmpty()) { Toast.makeText(this, "Chưa chọn ứng dụng nào", Toast.LENGTH_SHORT).show(); return }
        btn.isEnabled = false
        thread {
            var ok = 0
            val errors = mutableListOf<String>()
            todo.forEachIndexed { i, a ->
                runOnUiThread { status.text = "(${i + 1}/${todo.size}) Đang trích xuất ${a.label}…" }
                try { extract(a); ok++ } catch (e: Exception) { errors.add("${a.label}: ${e.message}") }
            }
            runOnUiThread {
                btn.isEnabled = true
                status.text = "Xong $ok/${todo.size}. Lưu tại Download/APK_Extractor" +
                    if (errors.isNotEmpty()) "\nLỗi: " + errors.joinToString("; ") else ""
            }
        }
    }

    private fun openOut(name: String, mime: String): OutputStream {
        val v = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/APK_Extractor")
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
            ?: throw Exception("Không tạo được file")
        return contentResolver.openOutputStream(uri) ?: throw Exception("Không ghi được file")
    }

    private fun obbFiles(pkg: String): List<File> =
        File(Environment.getExternalStorageDirectory(), "Android/obb/$pkg").listFiles()?.filter { it.isFile } ?: emptyList()

    // ---- Shell: root ưu tiên, sau đó Shizuku (quyền shell, đọc được Android/data & obb) ----
    private val rootOk by lazy {
        try { Runtime.getRuntime().exec(arrayOf("su", "-c", "id")).inputStream.bufferedReader().readText().contains("uid=0") }
        catch (e: Exception) { false }
    }
    private fun shizukuOk() = try { Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (e: Throwable) { false }
    private fun shizukuProc(cmd: String): Process? = try {
        val m = Shizuku::class.java.getDeclaredMethod("newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
        m.isAccessible = true
        m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
    } catch (e: Throwable) { null }
    private fun shell(cmd: String, needRoot: Boolean): Process? = when {
        rootOk -> try { Runtime.getRuntime().exec(arrayOf("su", "-c", cmd)) } catch (e: Exception) { null }
        !needRoot && shizukuOk() -> shizukuProc(cmd)
        else -> null
    }

    /** Chạy lệnh tar, ghi vào file tạm, chỉ thêm vào zip nếu có nội dung thật. */
    private fun tarToZip(z: ZipOutputStream, entry: String, cmd: String, needRoot: Boolean, notes: JSONArray) {
        val p = shell(cmd, needRoot)
        if (p == null) { notes.put("$entry: bỏ qua (thiếu ${if (needRoot) "root" else "root/Shizuku"})"); return }
        val tmp = File(cacheDir, "x.tar")
        tmp.outputStream().use { o -> p.inputStream.copyTo(o) }
        p.waitFor()
        if (tmp.length() > 1024) {
            z.putNextEntry(ZipEntry(entry)); tmp.inputStream().use { it.copyTo(z) }; z.closeEntry()
        } else notes.put("$entry: không có dữ liệu hoặc bị chặn")
        tmp.delete()
    }

    private fun info(a: AppItem): JSONObject {
        val pi = packageManager.getPackageInfo(a.pkg, PackageManager.GET_PERMISSIONS or PackageManager.GET_SIGNING_CERTIFICATES)
        val sig = JSONArray()
        pi.signingInfo?.apkContentsSigners?.forEach { s ->
            sig.put(MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) })
        }
        val perms = JSONArray(); pi.requestedPermissions?.forEach { perms.put(it) }
        val ai = pi.applicationInfo
        return JSONObject().put("package", a.pkg).put("name", a.label).put("versionName", a.version)
            .put("versionCode", pi.longVersionCode).put("minSdk", ai?.minSdkVersion).put("targetSdk", ai?.targetSdkVersion)
            .put("firstInstall", pi.firstInstallTime).put("lastUpdate", pi.lastUpdateTime)
            .put("signatureSha256", sig).put("permissions", perms)
    }

    private fun extract(a: AppItem) {
        val safe = (a.label.replace(Regex("[^\\p{L}\\p{N}_.\\- ]"), "_") + "_" + a.version).trim()
        val wantExt = extraBox.isChecked
        val wantData = dataBox.isChecked
        val obb = if (wantExt) obbFiles(a.pkg) else emptyList()
        if (a.files.size == 1 && !wantExt && !wantData) {
            openOut("$safe.apk", "application/vnd.android.package-archive").use { o -> a.files[0].inputStream().use { it.copyTo(o) } }
            return
        }
        val splits = JSONArray(); val notes = JSONArray(); val exp = JSONArray()
        ZipOutputStream(BufferedOutputStream(openOut("$safe.xapk", "application/octet-stream"))).use { z ->
            a.files.forEachIndexed { i, f ->
                val en = if (i == 0) "${a.pkg}.apk" else f.name
                z.putNextEntry(ZipEntry(en)); f.inputStream().use { it.copyTo(z) }; z.closeEntry()
                splits.put(JSONObject().put("file", en).put("id", if (i == 0) "base" else f.name.removeSuffix(".apk")))
            }
            obb.forEach { f ->
                val en = "Android/obb/${a.pkg}/${f.name}"
                z.putNextEntry(ZipEntry(en)); f.inputStream().use { it.copyTo(z) }; z.closeEntry()
                exp.put(JSONObject().put("file", en).put("install_path", en))
            }
            if (wantExt) {
                val base = "/storage/emulated/0/Android"
                if (obb.isEmpty()) tarToZip(z, "extra/obb.tar", "tar -cf - -C $base obb/${a.pkg} 2>/dev/null", false, notes)
                tarToZip(z, "extra/android_data.tar", "tar -cf - -C $base data/${a.pkg} 2>/dev/null", false, notes)
            }
            if (wantData) {
                tarToZip(z, "extra/internal_data.tar", "tar -cf - -C /data/data ${a.pkg} 2>/dev/null", true, notes)
                tarToZip(z, "extra/device_protected_data.tar", "tar -cf - -C /data/user_de/0 ${a.pkg} 2>/dev/null", true, notes)
            }
            val inf = info(a).put("notes", notes)
            z.putNextEntry(ZipEntry("info.json")); z.write(inf.toString(2).toByteArray()); z.closeEntry()
            val man = JSONObject().put("xapk_version", 2).put("package_name", a.pkg).put("name", a.label)
                .put("version_name", a.version).put("split_apks", splits).put("expansions", exp)
            z.putNextEntry(ZipEntry("manifest.json")); z.write(man.toString(2).toByteArray()); z.closeEntry()
        }
    }
}
